from datetime import date as date_type

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import require_roles
from app.models.user import User
from app.models.employee import Employee, Attendance
from app.models.du_sheet import DUSheet, DUSheetNozzle
from app.models.fuel import Tank, FuelType
from app.models.finance import LedgerEntry
from app.models.system import Setting
from app.schemas.dashboard import DashboardSummaryOut, TankStockSummary

router = APIRouter()


@router.get("/summary", response_model=DashboardSummaryOut)
def get_dashboard_summary(
    for_date: date_type | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Manager")),
):
    """One-shot KPI snapshot for the Owner/Manager home screen."""
    target_date = for_date or date_type.today()

    # Sales (from ledger — reflects only approved, posted DU Sheets).
    todays_sales_amount = (
        db.query(func.coalesce(func.sum(LedgerEntry.credit), 0))
        .filter(LedgerEntry.account_type == "sales", LedgerEntry.date == target_date)
        .scalar()
    )

    # Fuel volume sold today, from approved DU Sheets' nozzle entries.
    todays_fuel_sold_liters = (
        db.query(func.coalesce(func.sum(DUSheetNozzle.fuel_sold), 0))
        .join(DUSheet, DUSheet.id == DUSheetNozzle.du_sheet_id)
        .filter(DUSheet.date == target_date, DUSheet.status == "approved")
        .scalar()
    )

    # Attendance.
    total_employees = db.query(func.count(Employee.id)).scalar()
    present_count = (
        db.query(func.count(Attendance.id))
        .filter(Attendance.date == target_date, Attendance.status == "present")
        .scalar()
    )
    absent_count = (
        db.query(func.count(Attendance.id))
        .filter(Attendance.date == target_date, Attendance.status == "absent")
        .scalar()
    )

    # Pending approvals.
    pending_approvals = (
        db.query(func.count(DUSheet.id)).filter(DUSheet.status == "submitted").scalar()
    )

    # Tank stock, with a low-stock threshold pulled from Settings (default 20%).
    threshold_setting = db.query(Setting).filter(Setting.key == "low_stock_threshold_pct").first()
    try:
        low_stock_threshold = float(threshold_setting.value) if threshold_setting and threshold_setting.value else 20.0
    except ValueError:
        low_stock_threshold = 20.0

    tanks_out = []
    for tank in db.query(Tank).all():
        fuel_type = db.query(FuelType).filter(FuelType.id == tank.fuel_type_id).first()
        capacity = float(tank.capacity)
        fill_pct = round((float(tank.current_level) / capacity) * 100, 2) if capacity else 0.0
        tanks_out.append(TankStockSummary(
            tank_id=tank.id,
            tank_name=tank.name,
            fuel_type=fuel_type.name if fuel_type else "",
            current_level=tank.current_level,
            capacity=tank.capacity,
            fill_percentage=fill_pct,
            low_stock=fill_pct < low_stock_threshold,
        ))

    return DashboardSummaryOut(
        date=target_date,
        todays_sales_amount=float(todays_sales_amount),
        todays_fuel_sold_liters=float(todays_fuel_sold_liters),
        attendance_present=present_count,
        attendance_absent=absent_count,
        attendance_total_employees=total_employees,
        pending_du_sheet_approvals=pending_approvals,
        tanks=tanks_out,
    )
