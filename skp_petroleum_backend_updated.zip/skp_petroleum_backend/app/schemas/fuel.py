from datetime import date, datetime
from pydantic import BaseModel, Field


# ---------- Fuel Type ----------

class FuelTypeCreate(BaseModel):
    name: str  # Petrol / Diesel / CNG
    unit_price: float
    effective_date: date


class FuelTypeUpdate(BaseModel):
    """Use this to record a rate change — updates price + effective_date."""
    unit_price: float | None = None
    effective_date: date | None = None


class FuelTypeOut(BaseModel):
    id: int
    name: str
    unit_price: float
    effective_date: date

    model_config = {"from_attributes": True}


# ---------- Tank ----------

class TankCreate(BaseModel):
    fuel_type_id: int
    name: str
    capacity: float
    current_level: float = 0


class TankUpdate(BaseModel):
    name: str | None = None
    capacity: float | None = None


class TankOut(BaseModel):
    id: int
    fuel_type_id: int
    name: str
    capacity: float
    current_level: float

    model_config = {"from_attributes": True}


class TankStockOut(TankOut):
    fuel_type_name: str
    fill_percentage: float


# ---------- Dispensing Unit ----------

class DispensingUnitCreate(BaseModel):
    tank_id: int
    code: str  # e.g. DU-1


class DispensingUnitOut(BaseModel):
    id: int
    tank_id: int
    code: str

    model_config = {"from_attributes": True}


# ---------- Nozzle ----------

class NozzleCreate(BaseModel):
    dispensing_unit_id: int
    nozzle_number: str
    opening_meter: float = 0


class NozzleUpdate(BaseModel):
    """For correcting meter readings outside of the DU Sheet flow (admin fix)."""
    opening_meter: float | None = None
    closing_meter: float | None = None


class NozzleOut(BaseModel):
    id: int
    dispensing_unit_id: int
    nozzle_number: str
    opening_meter: float
    closing_meter: float

    model_config = {"from_attributes": True}


# ---------- Dip Reading ----------

class DipReadingCreate(BaseModel):
    tank_id: int
    reading_date: date
    dip_value: float
    calculated_volume: float


class DipReadingOut(BaseModel):
    id: int
    tank_id: int
    reading_date: date
    dip_value: float
    calculated_volume: float
    variance: float = Field(
        description="calculated_volume minus the tank's system current_level at read time"
    )

    model_config = {"from_attributes": True}


# ---------- Fuel Purchase ----------

class FuelPurchaseCreate(BaseModel):
    tank_id: int
    supplier: str
    quantity: float
    rate: float
    invoice_no: str | None = None
    purchase_date: date


class FuelPurchaseOut(BaseModel):
    id: int
    tank_id: int
    supplier: str
    quantity: float
    rate: float
    invoice_no: str | None = None
    purchase_date: date

    model_config = {"from_attributes": True}


# ---------- Inventory Log ----------

class InventoryLogOut(BaseModel):
    id: int
    tank_id: int
    change_type: str  # purchase / sale / adjustment
    quantity: float
    timestamp: datetime

    model_config = {"from_attributes": True}
