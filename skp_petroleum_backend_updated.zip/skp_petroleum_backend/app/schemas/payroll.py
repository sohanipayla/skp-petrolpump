from datetime import datetime
from pydantic import BaseModel, Field


# ---------- Payroll Cycle ----------

class PayrollCycleCreate(BaseModel):
    month: int = Field(ge=1, le=12)
    year: int


class PayrollCycleOut(BaseModel):
    id: int
    month: int
    year: int
    status: str  # open / processed / closed

    model_config = {"from_attributes": True}


class PayrollCycleDetailOut(PayrollCycleOut):
    payslips: list["PayslipOut"] = []


# ---------- Payslip ----------

class PayslipAdjust(BaseModel):
    """Adjust bonus/advance/deductions for one employee's payslip; net_salary is recalculated."""
    bonus: float | None = None
    advance: float | None = None
    deductions: float | None = None


class PayslipOut(BaseModel):
    id: int
    employee_id: int
    payroll_cycle_id: int
    base_salary: float
    bonus: float
    advance: float
    deductions: float
    net_salary: float
    generated_at: datetime

    model_config = {"from_attributes": True}


PayrollCycleDetailOut.model_rebuild()
