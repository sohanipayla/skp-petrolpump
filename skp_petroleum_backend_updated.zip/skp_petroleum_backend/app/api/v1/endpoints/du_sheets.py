from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import get_current_user, require_roles
from app.models.user import User
from app.models.du_sheet import DUSheet, DUSheetNozzle, Payment
from app.models.fuel import Nozzle, DispensingUnit, Tank, FuelType
from app.api.v1.endpoints.fuel import adjust_tank_stock
from app.api.v1.endpoints.finance import post_du_sheet_to_ledger
from app.schemas.du_sheet import (
    DUSheetCreate, DUSheetOut, DUSheetDetailOut,
    DUSheetNozzleCreate, DUSheetNozzleUpdate, DUSheetNozzleOut,
    PaymentCreate, PaymentOut,
    DUSheetDecision,
)

router = APIRouter()


def _get_du_sheet_or_404(db: Session, du_sheet_id: int) -> DUSheet:
    sheet = db.query(DUSheet).filter(DUSheet.id == du_sheet_id).first()
    if not sheet:
        raise HTTPException(status_code=404, detail="DU Sheet not found")
    return sheet


def _nozzle_tank_id(db: Session, nozzle_id: int) -> int:
    """Walks nozzle -> dispensing_unit -> tank and returns the tank id."""
    nozzle = db.query(Nozzle).filter(Nozzle.id == nozzle_id).first()
    if not nozzle:
        raise HTTPException(status_code=404, detail="Nozzle not found")
    du = db.query(DispensingUnit).filter(DispensingUnit.id == nozzle.dispensing_unit_id).first()
    if not du:
        raise HTTPException(status_code=404, detail="Dispensing unit not found")
    return du.tank_id


def _current_fuel_rate(db: Session, nozzle_id: int) -> float:
    """Walks nozzle -> dispensing_unit -> tank -> fuel_type to get today's rate."""
    tank_id = _nozzle_tank_id(db, nozzle_id)
    tank = db.query(Tank).filter(Tank.id == tank_id).first()
    fuel_type = db.query(FuelType).filter(FuelType.id == tank.fuel_type_id).first()
    return float(fuel_type.unit_price)


# ---------- DU Sheet CRUD ----------

@router.post("", response_model=DUSheetOut, status_code=status.HTTP_201_CREATED)
def create_du_sheet(
    payload: DUSheetCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sheet = DUSheet(**payload.model_dump(), status="draft")
    db.add(sheet)
    db.commit()
    db.refresh(sheet)
    return sheet


@router.get("", response_model=list[DUSheetOut])
def list_du_sheets(
    employee_id: int | None = None,
    status_filter: str | None = None,
    date_filter: date | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(DUSheet)
    if employee_id is not None:
        query = query.filter(DUSheet.employee_id == employee_id)
    if status_filter is not None:
        query = query.filter(DUSheet.status == status_filter)
    if date_filter is not None:
        query = query.filter(DUSheet.date == date_filter)
    return query.order_by(DUSheet.date.desc()).all()


@router.get("/{du_sheet_id}", response_model=DUSheetDetailOut)
def get_du_sheet(
    du_sheet_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _get_du_sheet_or_404(db, du_sheet_id)


# ---------- Nozzle entries (meter readings) ----------

@router.post(
    "/{du_sheet_id}/nozzle-entries",
    response_model=DUSheetNozzleOut,
    status_code=status.HTTP_201_CREATED,
)
def add_nozzle_entry(
    du_sheet_id: int,
    payload: DUSheetNozzleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sheet = _get_du_sheet_or_404(db, du_sheet_id)
    if sheet.status != "draft":
        raise HTTPException(status_code=400, detail="Can only add readings to a draft DU Sheet")

    entry = DUSheetNozzle(du_sheet_id=du_sheet_id, **payload.model_dump())
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.patch("/{du_sheet_id}/nozzle-entries/{entry_id}", response_model=DUSheetNozzleOut)
def update_nozzle_entry(
    du_sheet_id: int,
    entry_id: int,
    payload: DUSheetNozzleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Used for: OCR capture (ocr_raw_value), manual correction (verified_value),
    and setting the closing reading. Fuel sold + amount are auto-calculated
    from whichever value is most trusted: verified_value > closing_reading.
    """
    sheet = _get_du_sheet_or_404(db, du_sheet_id)
    if sheet.status != "draft":
        raise HTTPException(status_code=400, detail="Can only edit readings on a draft DU Sheet")

    entry = (
        db.query(DUSheetNozzle)
        .filter(DUSheetNozzle.id == entry_id, DUSheetNozzle.du_sheet_id == du_sheet_id)
        .first()
    )
    if not entry:
        raise HTTPException(status_code=404, detail="Nozzle entry not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(entry, field, value)

    raw_closing = entry.verified_value if entry.verified_value is not None else entry.closing_reading
    if raw_closing is not None:
        final_closing = float(raw_closing)
        opening = float(entry.opening_reading)
        if final_closing < opening:
            raise HTTPException(
                status_code=400,
                detail="Closing reading cannot be less than opening reading",
            )
        fuel_sold = final_closing - opening
        rate = _current_fuel_rate(db, entry.nozzle_id)
        entry.fuel_sold = fuel_sold
        entry.amount = round(fuel_sold * rate, 2)

    db.commit()
    db.refresh(entry)
    return entry


# ---------- Payments ----------

@router.post(
    "/{du_sheet_id}/payments",
    response_model=PaymentOut,
    status_code=status.HTTP_201_CREATED,
)
def add_payment(
    du_sheet_id: int,
    payload: PaymentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sheet = _get_du_sheet_or_404(db, du_sheet_id)
    if sheet.status != "draft":
        raise HTTPException(status_code=400, detail="Can only add payments to a draft DU Sheet")

    payment = Payment(du_sheet_id=du_sheet_id, **payload.model_dump())
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return payment


# ---------- Submit & Approval workflow ----------

@router.post("/{du_sheet_id}/submit", response_model=DUSheetOut)
def submit_du_sheet(
    du_sheet_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sheet = _get_du_sheet_or_404(db, du_sheet_id)
    if sheet.status != "draft":
        raise HTTPException(status_code=400, detail="Only a draft DU Sheet can be submitted")
    if not sheet.nozzle_entries:
        raise HTTPException(status_code=400, detail="Add at least one nozzle reading before submitting")

    incomplete = [e for e in sheet.nozzle_entries if e.fuel_sold is None]
    if incomplete:
        raise HTTPException(
            status_code=400,
            detail="All nozzle entries must have a closing/verified reading before submitting",
        )

    sheet.status = "submitted"
    sheet.submitted_at = datetime.utcnow()
    db.commit()
    db.refresh(sheet)
    return sheet


@router.patch("/{du_sheet_id}/decision", response_model=DUSheetOut)
def decide_du_sheet(
    du_sheet_id: int,
    payload: DUSheetDecision,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Manager")),
):
    if payload.status not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="status must be 'approved' or 'rejected'")

    sheet = _get_du_sheet_or_404(db, du_sheet_id)
    if sheet.status != "submitted":
        raise HTTPException(status_code=400, detail="Only a submitted DU Sheet can be approved/rejected")

    sheet.status = payload.status
    sheet.approved_by = current_user.id

    if payload.status == "approved":
        # Deduct each nozzle's sold quantity from its tank's stock.
        for entry in sheet.nozzle_entries:
            if entry.fuel_sold:
                tank_id = _nozzle_tank_id(db, entry.nozzle_id)
                adjust_tank_stock(db, tank_id, quantity_delta=-float(entry.fuel_sold), change_type="sale")
        # Post sales + collected payments to the ledger.
        post_du_sheet_to_ledger(db, sheet)

    db.commit()
    db.refresh(sheet)
    return sheet
