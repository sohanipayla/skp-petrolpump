from datetime import datetime
from typing import Any
from pydantic import BaseModel


# ---------- Notifications ----------

class NotificationCreate(BaseModel):
    user_id: int
    title: str
    message: str


class NotificationOut(BaseModel):
    id: int
    user_id: int
    title: str
    message: str
    is_read: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------- Audit Logs ----------

class AuditLogOut(BaseModel):
    id: int
    user_id: int | None = None
    action: str
    entity_type: str | None = None
    entity_id: int | None = None
    timestamp: datetime
    details: dict[str, Any]

    model_config = {"from_attributes": True}


# ---------- Settings ----------

class SettingUpsert(BaseModel):
    value: str | None = None


class SettingOut(BaseModel):
    id: int
    key: str
    value: str | None = None

    model_config = {"from_attributes": True}
