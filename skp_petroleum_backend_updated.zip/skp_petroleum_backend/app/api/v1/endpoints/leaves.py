from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import get_current_user, require_roles
from app.models.user import User
from app.models.employee import Leave
from app.schemas.employee import LeaveCreate, LeaveDecision, LeaveOut

router = APIRouter()


@router.post("", response_model=LeaveOut, status_code=status.HTTP_201_CREATED)
def apply_leave(
    payload: LeaveCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    leave = Leave(**payload.model_dump(), status="pending")
    db.add(leave)
    db.commit()
    db.refresh(leave)
    return leave


@router.get("", response_model=list[LeaveOut])
def list_leaves(
    employee_id: int | None = None,
    status_filter: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Leave)
    if employee_id is not None:
        query = query.filter(Leave.employee_id == employee_id)
    if status_filter is not None:
        query = query.filter(Leave.status == status_filter)
    return query.all()


@router.patch("/{leave_id}", response_model=LeaveOut)
def decide_leave(
    leave_id: int,
    payload: LeaveDecision,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Manager", "HR/Admin")),
):
    if payload.status not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="status must be 'approved' or 'rejected'")

    leave = db.query(Leave).filter(Leave.id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=404, detail="Leave request not found")

    leave.status = payload.status
    db.commit()
    db.refresh(leave)
    return leave
