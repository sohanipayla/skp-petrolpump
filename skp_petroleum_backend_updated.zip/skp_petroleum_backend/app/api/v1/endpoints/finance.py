from datetime import date

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import require_roles
from app.models.user import User
from app.models.finance import LedgerEntry, BankAccount, BankReconciliation, VATRecord
from app.schemas.finance import (
    LedgerEntryCreate, LedgerEntryOut,
    BankAccountCreate, BankAccountUpdate, BankAccountOut,
    BankReconciliationCreate, BankReconciliationDecision, BankReconciliationOut,
    VATRecordCreate, VATRecordFileStatus, VATRecordOut,
)

router = APIRouter()

# Per the PRD, Finance is Owner + Accountant only (Manager/HR/Attendant have no ledger access).
FINANCE_ROLES = ("Owner", "Accountant")


# ---------- Shared helper (also used by du_sheets on approval) ----------

def post_du_sheet_to_ledger(db: Session, sheet) -> None:
    """
    Posts ledger entries for a DU Sheet's fuel sales + collected payments.
    Does NOT commit — caller commits as part of its own transaction.
    """
    total_sales = sum(float(e.amount) for e in sheet.nozzle_entries if e.amount)
    if total_sales:
        db.add(LedgerEntry(
            date=sheet.date,
            account_type="sales",
            debit=0,
            credit=total_sales,
            reference_type="du_sheet",
            reference_id=sheet.id,
            description=f"Fuel sales - DU Sheet #{sheet.id}",
        ))

    for payment in sheet.payments:
        account_type = "cash" if payment.payment_mode.lower() == "cash" else "bank"
        db.add(LedgerEntry(
            date=sheet.date,
            account_type=account_type,
            debit=float(payment.amount),
            credit=0,
            reference_type="du_sheet",
            reference_id=sheet.id,
            description=f"Payment ({payment.payment_mode}) - DU Sheet #{sheet.id}",
        ))


# ---------- Ledger ----------
# Ledger is append-only for audit integrity — corrections go in as a new
# reversing entry, never an edit/delete of an existing one.

@router.post("/ledger-entries", response_model=LedgerEntryOut, status_code=status.HTTP_201_CREATED)
def create_ledger_entry(
    payload: LedgerEntryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    entry = LedgerEntry(**payload.model_dump())
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.get("/ledger-entries", response_model=list[LedgerEntryOut])
def list_ledger_entries(
    account_type: str | None = None,
    reference_type: str | None = None,
    reference_id: int | None = None,
    from_date: date | None = None,
    to_date: date | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    query = db.query(LedgerEntry)
    if account_type is not None:
        query = query.filter(LedgerEntry.account_type == account_type)
    if reference_type is not None:
        query = query.filter(LedgerEntry.reference_type == reference_type)
    if reference_id is not None:
        query = query.filter(LedgerEntry.reference_id == reference_id)
    if from_date is not None:
        query = query.filter(LedgerEntry.date >= from_date)
    if to_date is not None:
        query = query.filter(LedgerEntry.date <= to_date)
    return query.order_by(LedgerEntry.date.desc(), LedgerEntry.id.desc()).all()


# ---------- Bank Accounts ----------

@router.post("/bank-accounts", response_model=BankAccountOut, status_code=status.HTTP_201_CREATED)
def create_bank_account(
    payload: BankAccountCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    account = BankAccount(**payload.model_dump())
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


@router.get("/bank-accounts", response_model=list[BankAccountOut])
def list_bank_accounts(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    return db.query(BankAccount).order_by(BankAccount.bank_name).all()


@router.patch("/bank-accounts/{account_id}", response_model=BankAccountOut)
def update_bank_account(
    account_id: int,
    payload: BankAccountUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    account = db.query(BankAccount).filter(BankAccount.id == account_id).first()
    if not account:
        raise HTTPException(status_code=404, detail="Bank account not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(account, field, value)
    db.commit()
    db.refresh(account)
    return account


# ---------- Bank Reconciliation ----------

@router.post("/bank-reconciliations", response_model=BankReconciliationOut, status_code=status.HTTP_201_CREATED)
def create_bank_reconciliation(
    payload: BankReconciliationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    account = db.query(BankAccount).filter(BankAccount.id == payload.bank_account_id).first()
    if not account:
        raise HTTPException(status_code=404, detail="Bank account not found")

    recon = BankReconciliation(**payload.model_dump(), status="pending")
    db.add(recon)
    db.commit()
    db.refresh(recon)
    return recon


@router.get("/bank-reconciliations", response_model=list[BankReconciliationOut])
def list_bank_reconciliations(
    bank_account_id: int | None = None,
    status_filter: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    query = db.query(BankReconciliation)
    if bank_account_id is not None:
        query = query.filter(BankReconciliation.bank_account_id == bank_account_id)
    if status_filter is not None:
        query = query.filter(BankReconciliation.status == status_filter)
    return query.order_by(BankReconciliation.statement_date.desc()).all()


@router.patch("/bank-reconciliations/{recon_id}", response_model=BankReconciliationOut)
def decide_bank_reconciliation(
    recon_id: int,
    payload: BankReconciliationDecision,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    if payload.status not in ("matched", "mismatched"):
        raise HTTPException(status_code=400, detail="status must be 'matched' or 'mismatched'")

    recon = db.query(BankReconciliation).filter(BankReconciliation.id == recon_id).first()
    if not recon:
        raise HTTPException(status_code=404, detail="Reconciliation record not found")

    recon.status = payload.status
    if payload.status == "matched":
        account = db.query(BankAccount).filter(BankAccount.id == recon.bank_account_id).first()
        account.current_balance = recon.matched_amount

    db.commit()
    db.refresh(recon)
    return recon


# ---------- VAT Records ----------

@router.post("/vat-records", response_model=VATRecordOut, status_code=status.HTTP_201_CREATED)
def create_vat_record(
    payload: VATRecordCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    record = VATRecord(**payload.model_dump(), filed_status="pending")
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("/vat-records", response_model=list[VATRecordOut])
def list_vat_records(
    period: str | None = None,
    filed_status: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    query = db.query(VATRecord)
    if period is not None:
        query = query.filter(VATRecord.period == period)
    if filed_status is not None:
        query = query.filter(VATRecord.filed_status == filed_status)
    return query.order_by(VATRecord.period.desc()).all()


@router.patch("/vat-records/{record_id}", response_model=VATRecordOut)
def update_vat_file_status(
    record_id: int,
    payload: VATRecordFileStatus,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*FINANCE_ROLES)),
):
    if payload.filed_status not in ("pending", "filed"):
        raise HTTPException(status_code=400, detail="filed_status must be 'pending' or 'filed'")

    record = db.query(VATRecord).filter(VATRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="VAT record not found")

    record.filed_status = payload.filed_status
    db.commit()
    db.refresh(record)
    return record
