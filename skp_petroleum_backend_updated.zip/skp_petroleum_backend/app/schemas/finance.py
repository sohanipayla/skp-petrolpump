from datetime import date
from pydantic import BaseModel


# ---------- Ledger ----------

class LedgerEntryCreate(BaseModel):
    date: date
    account_type: str  # cash / bank / sales / expense ...
    debit: float = 0
    credit: float = 0
    reference_type: str | None = None  # e.g. "du_sheet"
    reference_id: int | None = None
    description: str | None = None


class LedgerEntryOut(BaseModel):
    id: int
    date: date
    account_type: str
    debit: float
    credit: float
    reference_type: str | None = None
    reference_id: int | None = None
    description: str | None = None

    model_config = {"from_attributes": True}


# ---------- Bank Account ----------

class BankAccountCreate(BaseModel):
    bank_name: str
    account_no: str
    ifsc: str | None = None
    current_balance: float = 0


class BankAccountUpdate(BaseModel):
    bank_name: str | None = None
    ifsc: str | None = None


class BankAccountOut(BaseModel):
    id: int
    bank_name: str
    account_no: str
    ifsc: str | None = None
    current_balance: float

    model_config = {"from_attributes": True}


# ---------- Bank Reconciliation ----------

class BankReconciliationCreate(BaseModel):
    bank_account_id: int
    statement_date: date
    matched_amount: float


class BankReconciliationDecision(BaseModel):
    status: str  # "matched" / "mismatched"


class BankReconciliationOut(BaseModel):
    id: int
    bank_account_id: int
    statement_date: date
    matched_amount: float
    status: str

    model_config = {"from_attributes": True}


# ---------- VAT Record ----------

class VATRecordCreate(BaseModel):
    period: str  # e.g. "2026-Q3"
    taxable_amount: float
    vat_amount: float


class VATRecordFileStatus(BaseModel):
    filed_status: str  # "pending" / "filed"


class VATRecordOut(BaseModel):
    id: int
    period: str
    taxable_amount: float
    vat_amount: float
    filed_status: str

    model_config = {"from_attributes": True}
