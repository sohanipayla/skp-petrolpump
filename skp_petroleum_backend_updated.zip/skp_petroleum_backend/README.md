# SKP Petroleum ERP — Backend (FastAPI + PostgreSQL)

v0.1: full database schema (20 tables across all PRD/TRD modules) +
working JWT login. Other modules' endpoints get added one by one from here.

## 1. Prerequisites
- Python 3.12+
- PostgreSQL 16+ running locally (or a connection string to one)

## 2. Setup

```bash
# create virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Mac/Linux

pip install -r requirements.txt
```

## 3. Configure environment

```bash
copy .env.example .env       # Windows
# cp .env.example .env       # Mac/Linux
```
Open `.env` and set `DATABASE_URL` to your Postgres connection, e.g.:
```
DATABASE_URL=postgresql+psycopg2://postgres:yourpassword@localhost:5432/skp_petroleum
```
Create the database first (one-time):
```sql
CREATE DATABASE skp_petroleum;
```

## 4. Run migrations (creates all 20 tables)

```bash
alembic revision --autogenerate -m "init schema"
alembic upgrade head
```

## 5. Seed default roles + demo login

```bash
python seed.py
```
This creates a demo Owner login: **owner@skppetroleum.com / Owner@123**

## 6. Run the server

```bash
uvicorn app.main:app --reload
```
- API base: `http://localhost:8000/api/v1`
- Interactive docs (Swagger): `http://localhost:8000/docs`

Test login via `/docs` → `POST /api/v1/auth/login` with the demo credentials above.

## What's built (v0.1)

- Full DB schema: Users/Roles, Employee Management (Employee, Shift,
  ShiftAssignment, Attendance, Leave, PerformanceRecord), Fuel Management
  (FuelType, Tank, DispensingUnit, Nozzle, DipReading, FuelPurchase,
  InventoryLog), DU Sheet (DUSheet, DUSheetNozzle, Payment), Finance
  (LedgerEntry, BankAccount, BankReconciliation, VATRecord), Payroll
  (PayrollCycle, Payslip), System (Notification, AuditLog, Setting)
- JWT auth: `POST /api/v1/auth/login`, `GET /api/v1/users/me`
- Role-based access helper: `require_roles('Owner', 'Manager')` in `app/api/deps.py`
- CORS configured for the Flutter web dev server

## Next steps (module by module)

For each module, the pattern is:
1. Add a `app/schemas/<module>.py` (Pydantic request/response models)
2. Add `app/api/v1/endpoints/<module>.py` (routes, using `get_db` +
   `require_roles` where PRD specifies role restrictions)
3. Register it in `app/api/v1/api.py`

Suggested order (matches the Flutter frontend build order):
1. Employee Management (CRUD, attendance, shifts, leave)
2. DU Sheet (create → OCR → verify → submit → approve) — the core workflow
3. Fuel Management (tanks, nozzles, dip readings, purchases)
4. Finance (ledger, bank reconciliation, VAT)
5. Payroll (cycle → payslip generation)
6. Reports (PDF via ReportLab, Excel via OpenPyXL)
7. Notifications, Settings, Audit Logs
