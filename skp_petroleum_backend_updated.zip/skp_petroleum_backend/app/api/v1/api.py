from fastapi import APIRouter

from app.api.v1.endpoints import auth, users, employees, shifts, attendance, leaves, du_sheets, fuel, finance, payroll, system, dashboard, reports

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Auth"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(employees.router, prefix="/employees", tags=["Employees"])
api_router.include_router(shifts.router, prefix="/shifts", tags=["Shifts"])
api_router.include_router(attendance.router, prefix="/attendance", tags=["Attendance"])
api_router.include_router(leaves.router, prefix="/leaves", tags=["Leaves"])
api_router.include_router(du_sheets.router, prefix="/du-sheets", tags=["DU Sheet"])
api_router.include_router(fuel.router, prefix="/fuel", tags=["Fuel Management"])
api_router.include_router(finance.router, prefix="/finance", tags=["Finance"])
api_router.include_router(payroll.router, prefix="/payroll", tags=["Payroll"])
api_router.include_router(system.router, prefix="/system", tags=["System"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
api_router.include_router(reports.router, prefix="/reports", tags=["Reports"])

# All PRD/TRD backend modules are now wired up.
