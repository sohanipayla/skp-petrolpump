from datetime import date, datetime

from sqlalchemy import String, ForeignKey, Date, DateTime, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class DUSheet(Base):
    __tablename__ = "du_sheets"

    id: Mapped[int] = mapped_column(primary_key=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("employees.id"))
    shift_id: Mapped[int] = mapped_column(ForeignKey("shifts.id"))
    date: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), default="draft")
    # draft / submitted / approved / rejected
    approved_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=True)
    submitted_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)

    nozzle_entries: Mapped[list["DUSheetNozzle"]] = relationship(back_populates="du_sheet")
    payments: Mapped[list["Payment"]] = relationship(back_populates="du_sheet")


class DUSheetNozzle(Base):
    __tablename__ = "du_sheet_nozzles"

    id: Mapped[int] = mapped_column(primary_key=True)
    du_sheet_id: Mapped[int] = mapped_column(ForeignKey("du_sheets.id"))
    nozzle_id: Mapped[int] = mapped_column(ForeignKey("nozzles.id"))
    opening_reading: Mapped[float] = mapped_column(Numeric(12, 2))
    closing_reading: Mapped[float] = mapped_column(Numeric(12, 2), nullable=True)
    ocr_raw_value: Mapped[str] = mapped_column(String(50), nullable=True)
    verified_value: Mapped[float] = mapped_column(Numeric(12, 2), nullable=True)
    fuel_sold: Mapped[float] = mapped_column(Numeric(10, 2), nullable=True)
    amount: Mapped[float] = mapped_column(Numeric(10, 2), nullable=True)

    du_sheet: Mapped["DUSheet"] = relationship(back_populates="nozzle_entries")


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True)
    du_sheet_id: Mapped[int] = mapped_column(ForeignKey("du_sheets.id"))
    payment_mode: Mapped[str] = mapped_column(String(20))  # cash / UPI / card
    amount: Mapped[float] = mapped_column(Numeric(10, 2))
    reference_no: Mapped[str] = mapped_column(String(50), nullable=True)

    du_sheet: Mapped["DUSheet"] = relationship(back_populates="payments")
