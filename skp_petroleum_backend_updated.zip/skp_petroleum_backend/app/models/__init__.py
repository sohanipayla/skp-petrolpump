"""
Import every model here so that:
1. `Base.metadata` knows about all tables (needed for Alembic autogenerate).
2. Other modules can do `from app.models import User, Employee, ...`
"""

from app.models.user import User, Role
from app.models.employee import (
    Employee,
    Shift,
    ShiftAssignment,
    Attendance,
    Leave,
    PerformanceRecord,
)
from app.models.fuel import (
    FuelType,
    Tank,
    DispensingUnit,
    Nozzle,
    DipReading,
    FuelPurchase,
    InventoryLog,
)
from app.models.du_sheet import DUSheet, DUSheetNozzle, Payment
from app.models.finance import LedgerEntry, BankAccount, BankReconciliation, VATRecord
from app.models.payroll import PayrollCycle, Payslip
from app.models.system import Notification, AuditLog, Setting

__all__ = [
    "User", "Role",
    "Employee", "Shift", "ShiftAssignment", "Attendance", "Leave", "PerformanceRecord",
    "FuelType", "Tank", "DispensingUnit", "Nozzle", "DipReading", "FuelPurchase", "InventoryLog",
    "DUSheet", "DUSheetNozzle", "Payment",
    "LedgerEntry", "BankAccount", "BankReconciliation", "VATRecord",
    "PayrollCycle", "Payslip",
    "Notification", "AuditLog", "Setting",
]
