import io
from datetime import date as date_type

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from openpyxl import Workbook
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from app.core.database import get_db
from app.api.deps import require_roles
from app.models.user import User
from app.models.du_sheet import DUSheet
from app.models.finance import LedgerEntry
from app.models.payroll import PayrollCycle
from app.models.employee import Employee

router = APIRouter()


# ---------- Shared export helpers ----------

def _build_xlsx(sheet_title: str, headers: list[str], rows: list[list]) -> io.BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_title[:31]
    ws.append(headers)
    for row in rows:
        ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def _build_pdf(title: str, headers: list[str], rows: list[list]) -> io.BytesIO:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = [Paragraph(title, styles["Title"]), Spacer(1, 12)]

    table_data = [headers] + [[str(cell) for cell in row] for row in rows]
    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f4f4")]),
    ]))
    elements.append(table)
    doc.build(elements)
    buf.seek(0)
    return buf


def _respond(buf: io.BytesIO, filename: str, fmt: str) -> StreamingResponse:
    media_type = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if fmt == "xlsx" else "application/pdf"
    )
    return StreamingResponse(
        buf,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def _validate_format(fmt: str) -> None:
    if fmt not in ("pdf", "xlsx"):
        raise HTTPException(status_code=400, detail="format must be 'pdf' or 'xlsx'")


# ---------- Sales / DU Sheet Report ----------

@router.get("/du-sheets")
def export_du_sheets_report(
    from_date: date_type,
    to_date: date_type,
    format: str = Query("pdf"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Manager")),
):
    _validate_format(format)

    sheets = (
        db.query(DUSheet)
        .filter(DUSheet.date >= from_date, DUSheet.date <= to_date, DUSheet.status == "approved")
        .order_by(DUSheet.date)
        .all()
    )

    headers = ["Date", "DU Sheet ID", "Employee ID", "Total Fuel Sold (L)", "Total Amount"]
    rows = []
    for sheet in sheets:
        total_fuel = sum(float(e.fuel_sold) for e in sheet.nozzle_entries if e.fuel_sold)
        total_amount = sum(float(e.amount) for e in sheet.nozzle_entries if e.amount)
        rows.append([str(sheet.date), sheet.id, sheet.employee_id, round(total_fuel, 2), round(total_amount, 2)])

    title = f"Sales Report ({from_date} to {to_date})"
    filename = f"sales_report_{from_date}_{to_date}.{format}"
    buf = _build_xlsx("Sales", headers, rows) if format == "xlsx" else _build_pdf(title, headers, rows)
    return _respond(buf, filename, format)


# ---------- Ledger / Finance Report ----------

@router.get("/ledger")
def export_ledger_report(
    from_date: date_type,
    to_date: date_type,
    format: str = Query("pdf"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Accountant")),
):
    _validate_format(format)

    entries = (
        db.query(LedgerEntry)
        .filter(LedgerEntry.date >= from_date, LedgerEntry.date <= to_date)
        .order_by(LedgerEntry.date, LedgerEntry.id)
        .all()
    )

    headers = ["Date", "Account", "Debit", "Credit", "Reference", "Description"]
    rows = [
        [
            str(e.date),
            e.account_type,
            round(float(e.debit), 2),
            round(float(e.credit), 2),
            f"{e.reference_type}#{e.reference_id}" if e.reference_type else "",
            e.description or "",
        ]
        for e in entries
    ]

    title = f"Ledger Report ({from_date} to {to_date})"
    filename = f"ledger_report_{from_date}_{to_date}.{format}"
    buf = _build_xlsx("Ledger", headers, rows) if format == "xlsx" else _build_pdf(title, headers, rows)
    return _respond(buf, filename, format)


# ---------- Payroll Report ----------

@router.get("/payroll/{cycle_id}")
def export_payroll_report(
    cycle_id: int,
    format: str = Query("pdf"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Accountant")),
):
    _validate_format(format)

    cycle = db.query(PayrollCycle).filter(PayrollCycle.id == cycle_id).first()
    if not cycle:
        raise HTTPException(status_code=404, detail="Payroll cycle not found")

    headers = ["Employee ID", "Employee Code", "Base Salary", "Bonus", "Advance", "Deductions", "Net Salary"]
    rows = []
    for p in cycle.payslips:
        emp = db.query(Employee).filter(Employee.id == p.employee_id).first()
        rows.append([
            p.employee_id,
            emp.employee_code if emp else "",
            round(float(p.base_salary), 2),
            round(float(p.bonus), 2),
            round(float(p.advance), 2),
            round(float(p.deductions), 2),
            round(float(p.net_salary), 2),
        ])

    title = f"Payroll Report - {cycle.month:02d}/{cycle.year}"
    filename = f"payroll_{cycle.month:02d}_{cycle.year}.{format}"
    buf = _build_xlsx("Payroll", headers, rows) if format == "xlsx" else _build_pdf(title, headers, rows)
    return _respond(buf, filename, format)
