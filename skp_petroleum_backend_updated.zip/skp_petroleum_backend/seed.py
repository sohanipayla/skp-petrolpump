"""
Run once after `alembic upgrade head` to create default roles and a
demo Owner login so you can test the API/frontend immediately.

Usage:
    python seed.py
"""

from app.core.database import SessionLocal
from app.core.security import hash_password
from app.models.user import Role, User

ROLE_NAMES = ["Owner", "Manager", "Accountant", "HR/Admin", "Fuel Attendant"]

db = SessionLocal()

try:
    role_map = {}
    for name in ROLE_NAMES:
        role = db.query(Role).filter(Role.name == name).first()
        if not role:
            role = Role(name=name, permissions={})
            db.add(role)
            db.flush()
        role_map[name] = role

    demo_email = "owner@skppetroleum.com"
    if not db.query(User).filter(User.email == demo_email).first():
        demo_user = User(
            name="Demo Owner",
            email=demo_email,
            password_hash=hash_password("Owner@123"),
            role_id=role_map["Owner"].id,
        )
        db.add(demo_user)

    db.commit()
    print("Seed complete.")
    print(f"Login with: {demo_email} / Owner@123")
finally:
    db.close()
