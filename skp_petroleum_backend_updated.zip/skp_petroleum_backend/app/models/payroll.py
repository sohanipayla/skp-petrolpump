from datetime import datetime

from sqlalchemy import String, ForeignKey, Integer, Numeric, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class PayrollCycle(Base):
    __tablename__ = "payroll_cycles"

    id: Mapped[int] = mapped_column(primary_key=True)
    month: Mapped[int] = mapped_column(Integer)
    year: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="open")  # open / processed / closed

    payslips: Mapped[list["Payslip"]] = relationship(back_populates="payroll_cycle")


class Payslip(Base):
    __tablename__ = "payslips"

    id: Mapped[int] = mapped_column(primary_key=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("employees.id"))
    payroll_cycle_id: Mapped[int] = mapped_column(ForeignKey("payroll_cycles.id"))
    base_salary: Mapped[float] = mapped_column(Numeric(10, 2))
    bonus: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    advance: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    deductions: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    net_salary: Mapped[float] = mapped_column(Numeric(10, 2))
    generated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    payroll_cycle: Mapped["PayrollCycle"] = relationship(back_populates="payslips")
