from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import get_current_user, require_roles
from app.models.user import User
from app.models.employee import Shift, ShiftAssignment
from app.schemas.employee import ShiftCreate, ShiftOut, ShiftAssignmentCreate, ShiftAssignmentOut

router = APIRouter()


@router.get("", response_model=list[ShiftOut])
def list_shifts(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Shift).all()


@router.post("", response_model=ShiftOut, status_code=status.HTTP_201_CREATED)
def create_shift(
    payload: ShiftCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Manager")),
):
    shift = Shift(**payload.model_dump())
    db.add(shift)
    db.commit()
    db.refresh(shift)
    return shift


@router.post("/assign", response_model=ShiftAssignmentOut, status_code=status.HTTP_201_CREATED)
def assign_shift(
    payload: ShiftAssignmentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Owner", "Manager")),
):
    assignment = ShiftAssignment(**payload.model_dump())
    db.add(assignment)
    db.commit()
    db.refresh(assignment)
    return assignment


@router.get("/assignments", response_model=list[ShiftAssignmentOut])
def list_assignments(
    employee_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(ShiftAssignment)
    if employee_id is not None:
        query = query.filter(ShiftAssignment.employee_id == employee_id)
    return query.all()
