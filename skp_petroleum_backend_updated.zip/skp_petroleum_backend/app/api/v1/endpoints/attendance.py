from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.employee import Attendance
from app.schemas.employee import PunchInRequest, PunchOutRequest, AttendanceOut

router = APIRouter()


@router.post("/punch-in", response_model=AttendanceOut, status_code=status.HTTP_201_CREATED)
def punch_in(
    payload: PunchInRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    today = date.today()
    existing = (
        db.query(Attendance)
        .filter(Attendance.employee_id == payload.employee_id, Attendance.date == today)
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Already punched in today")

    record = Attendance(
        employee_id=payload.employee_id,
        date=today,
        punch_in=datetime.utcnow(),
        status="present",
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.post("/punch-out", response_model=AttendanceOut)
def punch_out(
    payload: PunchOutRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    today = date.today()
    record = (
        db.query(Attendance)
        .filter(Attendance.employee_id == payload.employee_id, Attendance.date == today)
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="No punch-in record found for today")
    if record.punch_out:
        raise HTTPException(status_code=400, detail="Already punched out today")

    record.punch_out = datetime.utcnow()
    db.commit()
    db.refresh(record)
    return record


@router.get("", response_model=list[AttendanceOut])
def list_attendance(
    employee_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Attendance)
    if employee_id is not None:
        query = query.filter(Attendance.employee_id == employee_id)
    return query.order_by(Attendance.date.desc()).all()
