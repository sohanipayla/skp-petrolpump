from datetime import date, datetime
from pydantic import BaseModel


# ---------- DU Sheet ----------

class DUSheetCreate(BaseModel):
    employee_id: int
    shift_id: int
    date: date


class DUSheetOut(BaseModel):
    id: int
    employee_id: int
    shift_id: int
    date: date
    status: str
    approved_by: int | None = None
    submitted_at: datetime | None = None

    model_config = {"from_attributes": True}


class DUSheetDetailOut(DUSheetOut):
    nozzle_entries: list["DUSheetNozzleOut"] = []
    payments: list["PaymentOut"] = []


# ---------- Nozzle entry (meter reading) ----------

class DUSheetNozzleCreate(BaseModel):
    nozzle_id: int
    opening_reading: float


class DUSheetNozzleUpdate(BaseModel):
    """Used for OCR capture + manual verification + closing reading."""
    closing_reading: float | None = None
    ocr_raw_value: str | None = None
    verified_value: float | None = None


class DUSheetNozzleOut(BaseModel):
    id: int
    du_sheet_id: int
    nozzle_id: int
    opening_reading: float
    closing_reading: float | None = None
    ocr_raw_value: str | None = None
    verified_value: float | None = None
    fuel_sold: float | None = None
    amount: float | None = None

    model_config = {"from_attributes": True}


# ---------- Payment ----------

class PaymentCreate(BaseModel):
    payment_mode: str  # cash / UPI / card
    amount: float
    reference_no: str | None = None


class PaymentOut(BaseModel):
    id: int
    du_sheet_id: int
    payment_mode: str
    amount: float
    reference_no: str | None = None

    model_config = {"from_attributes": True}


# ---------- Approval ----------

class DUSheetDecision(BaseModel):
    status: str  # "approved" / "rejected"


DUSheetDetailOut.model_rebuild()
