from datetime import date
from pydantic import BaseModel


class TankStockSummary(BaseModel):
    tank_id: int
    tank_name: str
    fuel_type: str
    current_level: float
    capacity: float
    fill_percentage: float
    low_stock: bool


class DashboardSummaryOut(BaseModel):
    date: date
    todays_sales_amount: float
    todays_fuel_sold_liters: float
    attendance_present: int
    attendance_absent: int
    attendance_total_employees: int
    pending_du_sheet_approvals: int
    tanks: list[TankStockSummary]
