from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import require_roles
from app.models.user import User
from app.models.employee import Employee
from app.models.payroll import PayrollCycle, Payslip
from app.models.finance import LedgerEntry
from app.api.v1.endpoints.system import log_action
from app.schemas.payroll import (
    PayrollCycleCreate, PayrollCycleOut, PayrollCycleDetailOut,
    PayslipAdjust, PayslipOut,
)

router = APIRouter()

# Per the PRD: Accountant runs payroll, HR/Admin prepares it, Owner has full access.
PAYROLL_ROLES = ("Owner", "Accountant", "HR/Admin")


def _get_cycle_or_404(db: Session, cycle_id: int) -> PayrollCycle:
    cycle = db.query(PayrollCycle).filter(PayrollCycle.id == cycle_id).first()
    if not cycle:
        raise HTTPException(status_code=404, detail="Payroll cycle not found")
    return cycle


def _recalc_net_salary(payslip: Payslip) -> None:
    payslip.net_salary = round(
        float(payslip.base_salary) + float(payslip.bonus) - float(payslip.advance) - float(payslip.deductions),
        2,
    )


# ---------- Payroll Cycles ----------

@router.post("/cycles", response_model=PayrollCycleOut, status_code=status.HTTP_201_CREATED)
def create_payroll_cycle(
    payload: PayrollCycleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    existing = (
        db.query(PayrollCycle)
        .filter(PayrollCycle.month == payload.month, PayrollCycle.year == payload.year)
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="A payroll cycle for this month/year already exists")

    cycle = PayrollCycle(month=payload.month, year=payload.year, status="open")
    db.add(cycle)
    db.commit()
    db.refresh(cycle)
    return cycle


@router.get("/cycles", response_model=list[PayrollCycleOut])
def list_payroll_cycles(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    return db.query(PayrollCycle).order_by(PayrollCycle.year.desc(), PayrollCycle.month.desc()).all()


@router.get("/cycles/{cycle_id}", response_model=PayrollCycleDetailOut)
def get_payroll_cycle(
    cycle_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    return _get_cycle_or_404(db, cycle_id)


@router.post("/cycles/{cycle_id}/generate", response_model=PayrollCycleDetailOut)
def generate_payslips(
    cycle_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    """
    Creates one payslip per active employee from their base salary
    (salary_base on the Employee record). Bonus/advance/deductions default
    to 0 and can be adjusted per-payslip afterwards, before the cycle closes.
    """
    cycle = _get_cycle_or_404(db, cycle_id)
    if cycle.status != "open":
        raise HTTPException(status_code=400, detail="Payslips can only be generated for an open cycle")

    existing_employee_ids = {p.employee_id for p in cycle.payslips}
    employees = db.query(Employee).all()

    created = 0
    for emp in employees:
        if emp.id in existing_employee_ids:
            continue
        base_salary = float(emp.salary_base)
        payslip = Payslip(
            employee_id=emp.id,
            payroll_cycle_id=cycle.id,
            base_salary=base_salary,
            bonus=0,
            advance=0,
            deductions=0,
            net_salary=base_salary,
        )
        db.add(payslip)
        created += 1

    if created == 0 and not existing_employee_ids:
        raise HTTPException(status_code=400, detail="No employees found to generate payslips for")

    cycle.status = "processed"
    db.commit()
    db.refresh(cycle)
    return cycle


@router.post("/cycles/{cycle_id}/close", response_model=PayrollCycleOut)
def close_payroll_cycle(
    cycle_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    """Locks the cycle (no further payslip edits) and posts the payout to the ledger."""
    cycle = _get_cycle_or_404(db, cycle_id)
    if cycle.status != "processed":
        raise HTTPException(status_code=400, detail="Only a processed cycle can be closed")
    if not cycle.payslips:
        raise HTTPException(status_code=400, detail="Cannot close a cycle with no payslips")

    total_net = sum(float(p.net_salary) for p in cycle.payslips)
    label = f"{cycle.month:02d}/{cycle.year}"

    db.add(LedgerEntry(
        date=cycle.payslips[0].generated_at.date(),
        account_type="salary_expense",
        debit=total_net,
        credit=0,
        reference_type="payroll_cycle",
        reference_id=cycle.id,
        description=f"Payroll payout - {label}",
    ))
    db.add(LedgerEntry(
        date=cycle.payslips[0].generated_at.date(),
        account_type="bank",
        debit=0,
        credit=total_net,
        reference_type="payroll_cycle",
        reference_id=cycle.id,
        description=f"Payroll payout - {label}",
    ))

    cycle.status = "closed"
    log_action(
        db, current_user.id, "payroll_cycle.close",
        entity_type="payroll_cycle", entity_id=cycle.id, details={"total_net": total_net},
    )
    db.commit()
    db.refresh(cycle)
    return cycle


# ---------- Payslips ----------

@router.get("/payslips", response_model=list[PayslipOut])
def list_payslips(
    employee_id: int | None = None,
    payroll_cycle_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    query = db.query(Payslip)
    if employee_id is not None:
        query = query.filter(Payslip.employee_id == employee_id)
    if payroll_cycle_id is not None:
        query = query.filter(Payslip.payroll_cycle_id == payroll_cycle_id)
    return query.order_by(Payslip.generated_at.desc()).all()


@router.get("/payslips/{payslip_id}", response_model=PayslipOut)
def get_payslip(
    payslip_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    payslip = db.query(Payslip).filter(Payslip.id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=404, detail="Payslip not found")
    return payslip


@router.patch("/payslips/{payslip_id}", response_model=PayslipOut)
def adjust_payslip(
    payslip_id: int,
    payload: PayslipAdjust,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*PAYROLL_ROLES)),
):
    payslip = db.query(Payslip).filter(Payslip.id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=404, detail="Payslip not found")

    cycle = _get_cycle_or_404(db, payslip.payroll_cycle_id)
    if cycle.status == "closed":
        raise HTTPException(status_code=400, detail="Cannot adjust a payslip in a closed cycle")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(payslip, field, value)
    _recalc_net_salary(payslip)

    db.commit()
    db.refresh(payslip)
    return payslip
