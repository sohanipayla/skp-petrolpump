from datetime import date, datetime, time
from pydantic import BaseModel, EmailStr


# ---------- Employee ----------

class EmployeeCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role_name: str  # "Owner" / "Manager" / "Accountant" / "HR/Admin" / "Fuel Attendant"
    employee_code: str
    phone: str | None = None
    address: str | None = None
    joining_date: date | None = None
    designation: str | None = None
    salary_base: float = 0


class EmployeeUpdate(BaseModel):
    phone: str | None = None
    address: str | None = None
    designation: str | None = None
    salary_base: float | None = None


class EmployeeOut(BaseModel):
    id: int
    employee_code: str
    name: str
    email: EmailStr
    role: str
    phone: str | None = None
    designation: str | None = None
    joining_date: date | None = None
    salary_base: float

    model_config = {"from_attributes": True}


# ---------- Shift ----------

class ShiftCreate(BaseModel):
    name: str
    start_time: time
    end_time: time


class ShiftOut(BaseModel):
    id: int
    name: str
    start_time: time
    end_time: time

    model_config = {"from_attributes": True}


class ShiftAssignmentCreate(BaseModel):
    employee_id: int
    shift_id: int
    date: date


class ShiftAssignmentOut(BaseModel):
    id: int
    employee_id: int
    shift_id: int
    date: date

    model_config = {"from_attributes": True}


# ---------- Attendance ----------

class PunchInRequest(BaseModel):
    employee_id: int


class PunchOutRequest(BaseModel):
    employee_id: int


class AttendanceOut(BaseModel):
    id: int
    employee_id: int
    date: date
    punch_in: datetime | None = None
    punch_out: datetime | None = None
    status: str

    model_config = {"from_attributes": True}


# ---------- Leave ----------

class LeaveCreate(BaseModel):
    employee_id: int
    leave_type: str
    from_date: date
    to_date: date


class LeaveDecision(BaseModel):
    status: str  # "approved" / "rejected"


class LeaveOut(BaseModel):
    id: int
    employee_id: int
    leave_type: str
    from_date: date
    to_date: date
    status: str

    model_config = {"from_attributes": True}
