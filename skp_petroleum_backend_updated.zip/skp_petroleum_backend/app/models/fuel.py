from datetime import date, datetime

from sqlalchemy import String, ForeignKey, Date, DateTime, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class FuelType(Base):
    __tablename__ = "fuel_types"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))  # Petrol / Diesel / CNG
    unit_price: Mapped[float] = mapped_column(Numeric(10, 2))
    effective_date: Mapped[date] = mapped_column(Date)


class Tank(Base):
    __tablename__ = "tanks"

    id: Mapped[int] = mapped_column(primary_key=True)
    fuel_type_id: Mapped[int] = mapped_column(ForeignKey("fuel_types.id"))
    name: Mapped[str] = mapped_column(String(50))
    capacity: Mapped[float] = mapped_column(Numeric(10, 2))
    current_level: Mapped[float] = mapped_column(Numeric(10, 2), default=0)

    dispensing_units: Mapped[list["DispensingUnit"]] = relationship(back_populates="tank")


class DispensingUnit(Base):
    __tablename__ = "dispensing_units"

    id: Mapped[int] = mapped_column(primary_key=True)
    tank_id: Mapped[int] = mapped_column(ForeignKey("tanks.id"))
    code: Mapped[str] = mapped_column(String(30))  # e.g. DU-1

    tank: Mapped["Tank"] = relationship(back_populates="dispensing_units")
    nozzles: Mapped[list["Nozzle"]] = relationship(back_populates="dispensing_unit")


class Nozzle(Base):
    __tablename__ = "nozzles"

    id: Mapped[int] = mapped_column(primary_key=True)
    dispensing_unit_id: Mapped[int] = mapped_column(ForeignKey("dispensing_units.id"))
    nozzle_number: Mapped[str] = mapped_column(String(10))
    opening_meter: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    closing_meter: Mapped[float] = mapped_column(Numeric(12, 2), default=0)

    dispensing_unit: Mapped["DispensingUnit"] = relationship(back_populates="nozzles")


class DipReading(Base):
    __tablename__ = "dip_readings"

    id: Mapped[int] = mapped_column(primary_key=True)
    tank_id: Mapped[int] = mapped_column(ForeignKey("tanks.id"))
    reading_date: Mapped[date] = mapped_column(Date)
    dip_value: Mapped[float] = mapped_column(Numeric(10, 2))
    calculated_volume: Mapped[float] = mapped_column(Numeric(10, 2))


class FuelPurchase(Base):
    __tablename__ = "fuel_purchases"

    id: Mapped[int] = mapped_column(primary_key=True)
    tank_id: Mapped[int] = mapped_column(ForeignKey("tanks.id"))
    supplier: Mapped[str] = mapped_column(String(150))
    quantity: Mapped[float] = mapped_column(Numeric(10, 2))
    rate: Mapped[float] = mapped_column(Numeric(10, 2))
    invoice_no: Mapped[str] = mapped_column(String(50), nullable=True)
    purchase_date: Mapped[date] = mapped_column(Date)


class InventoryLog(Base):
    __tablename__ = "inventory_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    tank_id: Mapped[int] = mapped_column(ForeignKey("tanks.id"))
    change_type: Mapped[str] = mapped_column(String(20))  # purchase / sale / adjustment
    quantity: Mapped[float] = mapped_column(Numeric(10, 2))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
