from datetime import date

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.deps import get_current_user, require_roles
from app.models.user import User
from app.models.fuel import (
    FuelType, Tank, DispensingUnit, Nozzle, DipReading, FuelPurchase, InventoryLog,
)
from app.schemas.fuel import (
    FuelTypeCreate, FuelTypeUpdate, FuelTypeOut,
    TankCreate, TankUpdate, TankOut, TankStockOut,
    DispensingUnitCreate, DispensingUnitOut,
    NozzleCreate, NozzleUpdate, NozzleOut,
    DipReadingCreate, DipReadingOut,
    FuelPurchaseCreate, FuelPurchaseOut,
    InventoryLogOut,
)

router = APIRouter()

MANAGE_ROLES = ("Owner", "Manager")


# ---------- Shared inventory helper (also used by du_sheets on approval) ----------

def adjust_tank_stock(db: Session, tank_id: int, quantity_delta: float, change_type: str) -> Tank:
    """
    Applies a stock change to a tank and records an InventoryLog entry.
    Does NOT commit — caller commits as part of its own transaction.
    quantity_delta is signed (positive for purchase/adjustment-in, negative for sale).
    """
    tank = db.query(Tank).filter(Tank.id == tank_id).first()
    if not tank:
        raise HTTPException(status_code=404, detail="Tank not found")

    new_level = float(tank.current_level) + quantity_delta
    if new_level < 0:
        raise HTTPException(status_code=400, detail=f"Insufficient stock in tank '{tank.name}'")

    tank.current_level = new_level
    db.add(InventoryLog(tank_id=tank_id, change_type=change_type, quantity=abs(quantity_delta)))
    return tank


def _get_tank_or_404(db: Session, tank_id: int) -> Tank:
    tank = db.query(Tank).filter(Tank.id == tank_id).first()
    if not tank:
        raise HTTPException(status_code=404, detail="Tank not found")
    return tank


# ---------- Fuel Types ----------

@router.post("/fuel-types", response_model=FuelTypeOut, status_code=status.HTTP_201_CREATED)
def create_fuel_type(
    payload: FuelTypeCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    fuel_type = FuelType(**payload.model_dump())
    db.add(fuel_type)
    db.commit()
    db.refresh(fuel_type)
    return fuel_type


@router.get("/fuel-types", response_model=list[FuelTypeOut])
def list_fuel_types(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return db.query(FuelType).order_by(FuelType.name).all()


@router.patch("/fuel-types/{fuel_type_id}", response_model=FuelTypeOut)
def update_fuel_type(
    fuel_type_id: int,
    payload: FuelTypeUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    """Use to record a rate change (updates unit_price / effective_date)."""
    fuel_type = db.query(FuelType).filter(FuelType.id == fuel_type_id).first()
    if not fuel_type:
        raise HTTPException(status_code=404, detail="Fuel type not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(fuel_type, field, value)

    db.commit()
    db.refresh(fuel_type)
    return fuel_type


# ---------- Tanks ----------

@router.post("/tanks", response_model=TankOut, status_code=status.HTTP_201_CREATED)
def create_tank(
    payload: TankCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    tank = Tank(**payload.model_dump())
    db.add(tank)
    db.commit()
    db.refresh(tank)
    return tank


@router.get("/tanks", response_model=list[TankOut])
def list_tanks(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return db.query(Tank).order_by(Tank.name).all()


@router.get("/tanks/{tank_id}", response_model=TankStockOut)
def get_tank(
    tank_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    tank = _get_tank_or_404(db, tank_id)
    fuel_type = db.query(FuelType).filter(FuelType.id == tank.fuel_type_id).first()
    capacity = float(tank.capacity)
    fill_pct = round((float(tank.current_level) / capacity) * 100, 2) if capacity else 0.0
    return TankStockOut(
        id=tank.id,
        fuel_type_id=tank.fuel_type_id,
        name=tank.name,
        capacity=tank.capacity,
        current_level=tank.current_level,
        fuel_type_name=fuel_type.name if fuel_type else "",
        fill_percentage=fill_pct,
    )


@router.patch("/tanks/{tank_id}", response_model=TankOut)
def update_tank(
    tank_id: int,
    payload: TankUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    tank = _get_tank_or_404(db, tank_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(tank, field, value)
    db.commit()
    db.refresh(tank)
    return tank


# ---------- Dispensing Units ----------

@router.post("/dispensing-units", response_model=DispensingUnitOut, status_code=status.HTTP_201_CREATED)
def create_dispensing_unit(
    payload: DispensingUnitCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    _get_tank_or_404(db, payload.tank_id)
    du = DispensingUnit(**payload.model_dump())
    db.add(du)
    db.commit()
    db.refresh(du)
    return du


@router.get("/dispensing-units", response_model=list[DispensingUnitOut])
def list_dispensing_units(
    tank_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(DispensingUnit)
    if tank_id is not None:
        query = query.filter(DispensingUnit.tank_id == tank_id)
    return query.order_by(DispensingUnit.code).all()


# ---------- Nozzles ----------

@router.post("/nozzles", response_model=NozzleOut, status_code=status.HTTP_201_CREATED)
def create_nozzle(
    payload: NozzleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    du = db.query(DispensingUnit).filter(DispensingUnit.id == payload.dispensing_unit_id).first()
    if not du:
        raise HTTPException(status_code=404, detail="Dispensing unit not found")
    nozzle = Nozzle(**payload.model_dump())
    db.add(nozzle)
    db.commit()
    db.refresh(nozzle)
    return nozzle


@router.get("/nozzles", response_model=list[NozzleOut])
def list_nozzles(
    dispensing_unit_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Nozzle)
    if dispensing_unit_id is not None:
        query = query.filter(Nozzle.dispensing_unit_id == dispensing_unit_id)
    return query.order_by(Nozzle.nozzle_number).all()


@router.patch("/nozzles/{nozzle_id}", response_model=NozzleOut)
def update_nozzle(
    nozzle_id: int,
    payload: NozzleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    """Admin correction of meter readings outside the normal DU Sheet flow."""
    nozzle = db.query(Nozzle).filter(Nozzle.id == nozzle_id).first()
    if not nozzle:
        raise HTTPException(status_code=404, detail="Nozzle not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(nozzle, field, value)
    db.commit()
    db.refresh(nozzle)
    return nozzle


# ---------- Dip Readings ----------

@router.post("/dip-readings", response_model=DipReadingOut, status_code=status.HTTP_201_CREATED)
def create_dip_reading(
    payload: DipReadingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    tank = _get_tank_or_404(db, payload.tank_id)
    reading = DipReading(**payload.model_dump())
    db.add(reading)
    db.commit()
    db.refresh(reading)
    variance = round(float(reading.calculated_volume) - float(tank.current_level), 2)
    return DipReadingOut(
        id=reading.id, tank_id=reading.tank_id, reading_date=reading.reading_date,
        dip_value=reading.dip_value, calculated_volume=reading.calculated_volume, variance=variance,
    )


@router.get("/dip-readings", response_model=list[DipReadingOut])
def list_dip_readings(
    tank_id: int | None = None,
    reading_date: date | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(DipReading)
    if tank_id is not None:
        query = query.filter(DipReading.tank_id == tank_id)
    if reading_date is not None:
        query = query.filter(DipReading.reading_date == reading_date)
    readings = query.order_by(DipReading.reading_date.desc()).all()

    out = []
    for r in readings:
        tank = db.query(Tank).filter(Tank.id == r.tank_id).first()
        variance = round(float(r.calculated_volume) - float(tank.current_level), 2) if tank else 0.0
        out.append(DipReadingOut(
            id=r.id, tank_id=r.tank_id, reading_date=r.reading_date,
            dip_value=r.dip_value, calculated_volume=r.calculated_volume, variance=variance,
        ))
    return out


# ---------- Fuel Purchases ----------

@router.post("/fuel-purchases", response_model=FuelPurchaseOut, status_code=status.HTTP_201_CREATED)
def create_fuel_purchase(
    payload: FuelPurchaseCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    """Recording a purchase also credits the tank's stock and logs it."""
    _get_tank_or_404(db, payload.tank_id)

    purchase = FuelPurchase(**payload.model_dump())
    db.add(purchase)
    adjust_tank_stock(db, payload.tank_id, quantity_delta=payload.quantity, change_type="purchase")

    db.commit()
    db.refresh(purchase)
    return purchase


@router.get("/fuel-purchases", response_model=list[FuelPurchaseOut])
def list_fuel_purchases(
    tank_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(FuelPurchase)
    if tank_id is not None:
        query = query.filter(FuelPurchase.tank_id == tank_id)
    return query.order_by(FuelPurchase.purchase_date.desc()).all()


# ---------- Inventory Logs ----------

@router.get("/inventory-logs", response_model=list[InventoryLogOut])
def list_inventory_logs(
    tank_id: int | None = None,
    change_type: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(InventoryLog)
    if tank_id is not None:
        query = query.filter(InventoryLog.tank_id == tank_id)
    if change_type is not None:
        query = query.filter(InventoryLog.change_type == change_type)
    return query.order_by(InventoryLog.timestamp.desc()).all()
