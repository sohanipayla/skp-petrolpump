from datetime import date

from sqlalchemy import String, Date, Numeric, Text, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class LedgerEntry(Base):
    __tablename__ = "ledger_entries"

    id: Mapped[int] = mapped_column(primary_key=True)
    date: Mapped[date] = mapped_column(Date)
    account_type: Mapped[str] = mapped_column(String(50))  # cash / bank / sales / expense ...
    debit: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    credit: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    reference_type: Mapped[str] = mapped_column(String(50), nullable=True)  # e.g. "du_sheet"
    reference_id: Mapped[int] = mapped_column(Integer, nullable=True)
    description: Mapped[str] = mapped_column(Text, nullable=True)


class BankAccount(Base):
    __tablename__ = "bank_accounts"

    id: Mapped[int] = mapped_column(primary_key=True)
    bank_name: Mapped[str] = mapped_column(String(100))
    account_no: Mapped[str] = mapped_column(String(50))
    ifsc: Mapped[str] = mapped_column(String(20), nullable=True)
    current_balance: Mapped[float] = mapped_column(Numeric(12, 2), default=0)


class BankReconciliation(Base):
    __tablename__ = "bank_reconciliations"

    id: Mapped[int] = mapped_column(primary_key=True)
    bank_account_id: Mapped[int] = mapped_column(ForeignKey("bank_accounts.id"))
    statement_date: Mapped[date] = mapped_column(Date)
    matched_amount: Mapped[float] = mapped_column(Numeric(12, 2))
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending / matched / mismatched


class VATRecord(Base):
    __tablename__ = "vat_records"

    id: Mapped[int] = mapped_column(primary_key=True)
    period: Mapped[str] = mapped_column(String(20))  # e.g. "2026-Q3"
    taxable_amount: Mapped[float] = mapped_column(Numeric(12, 2))
    vat_amount: Mapped[float] = mapped_column(Numeric(12, 2))
    filed_status: Mapped[str] = mapped_column(String(20), default="pending")
